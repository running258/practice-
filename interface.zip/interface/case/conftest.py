# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/14 13:29

import pytest
from common import viewHighMysqlDB
from common.viewHighLogger import Logger
from common.viewHighYamlConf import YamlConf
from common.viewHighSystem import get_abs_path

log = Logger(loggerName="ApiTest_Dalian_conftest").getLog()


def pytest_addoption(parser):
    parser.addoption("--runEnv", action="store", default="staging",
                     help="env option:staging or demo or test")
    parser.addoption("--supplierUserInfo", action="store",
                     default='{"userName": "taojin002", "password": "taojin1234", "supplierName": ""}')


@pytest.fixture(scope="class")
def runEnv(request):
    return request.config.getoption("--runEnv")


@pytest.fixture
def supplierUserInfo(request):
    return request.config.getoption("--supplierUserInfo")


# 初始化数据库fixture
@pytest.fixture(scope="class")
def initialize_database(runEnv):
    filePath = get_abs_path() + r"/file/yamlFile/supplierSql.yaml"
    sqlDict = YamlConf(filePath).get_param(nodeName="supplierSql")
    for sql in sqlDict:
        if runEnv == "staging":
            viewHighMysqlDB.clear_database(env=runEnv, sql_delete=sqlDict[sql].encode("utf-8"))
        elif runEnv == "test":
            viewHighMysqlDB.clear_database(env=runEnv, dbName="viewchaindb", sql_delete=sqlDict[sql].encode("utf-8"))
        elif runEnv == "demo":
            viewHighMysqlDB.clear_database(env=runEnv, dbName="viewchaindb_demo",
                                           sql_delete=sqlDict[sql].encode("utf-8"))

    log.info("<接口自动化测试>相关的证件已经从数据库清除!")
