# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/9 13:13
import random
import pytest
import time
from collections import namedtuple
import sys

Task = namedtuple("Task", ["test", "summary", "owner", "done", "id"])


class TestLesson(object):
    def test_pass1(self):
        time.sleep(0.2)
        assert [1, 2, 3] == range(1, 4)

    def test_pass2(self):
        assert "me" in "member"

    def test_fail1(self):
        time.sleep(0.4)
        assert (1, 2, 3) == (2, 3, 4)

    @pytest.mark.parametrize("a, b", [(1, 1), (2, 4)], ids=["1 is equal to 1", "2 不等于 4"])
    @pytest.mark.ptest
    def test_fail2(self, a, b):
        assert a == b
        print "a is equal b"

    @staticmethod
    @pytest.mark.ptest
    def test_answer(runEnv):
        assert runEnv == "staging"

    @pytest.mark.ptest
    def test_userInfo(self, userInfo):
        print userInfo,type(userInfo)
        assert type(userInfo) == dict


if __name__ == '__main__':
    # task = Task("case", "20", "taojin", "yes", "312931")
    # print task
    pytest.main(r"\ApiTest_DaLian\case -m ptest -v --runEnv=staging --userInfo={'userName':'whtest001','password':''}")
    # pytest.main(r"E:\ApiTest_DaLian\testCase -v --tb=line --html=./testReport11.html")
