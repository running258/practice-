# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/26 14:05
import os
from common.viewHighSystem import get_abs_path

reportPath = get_abs_path() + r"/result/report/测试报告.html"
os.system("py.test " + os.getcwd() + " -l -s --html=%s" % reportPath)
