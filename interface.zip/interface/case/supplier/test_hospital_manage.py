# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/12/11 13:37
import json
from common.viewHighSystem import get_abs_path, obj_show_Chinese
from common.viewHighYamlConf import YamlConf
from common.viewHighRequest import SupplyRequests
from common.viewHighLogger import Logger

log = Logger(loggerName="医院管理").getLog()


class TestHospitalManage(object):
    userToken = {}
    hospitalName = "接口自动化测试厂商"
    yamlInfo = YamlConf(get_abs_path() + r"/file/yamlFile/hospital_manage.yaml")

    # case0, 用户登录并获取cookie信息，用于后续接口调用的用户凭证
    def test_user_login(self, runEnv, supplierUserInfo):
        supplierUserInfo = eval(supplierUserInfo)
        userName = supplierUserInfo["userName"]
        password = supplierUserInfo["password"]
        log.info("----材料证件接口自动化测试开始，用户%s_%s登录系统-----" % (userName, password))
        token = SupplyRequests(runEnv).get_user_token(userName=userName, password=password)
        self.userToken.update(token)
        # 获取登录用户的菜单权限
        SupplyRequests(runEnv).get_user_authorization(token)

    def test_all_bound_hospital(self, runEnv):
        url = self.yamlInfo.get_url("allBoundHospital")
        param = self.yamlInfo.get_param("allBoundHospital")
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        assert response.json()["status"] == 1
        log.info("查询到的全部已绑定医院列表数量为%s" % str(len(response.json()["result"])))

    def test_bound_hospital_by_name(self, runEnv):
        url = self.yamlInfo.get_url("boundHospitalByName")
        param = self.yamlInfo.get_param("boundHospitalByName")
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        assert response.json()["status"] == 1
        hospitalNameList = []
        # 如果查询结果不为空,则将所有查询结果的医院名称存入hospitalNameList中,断言入参医院名称与出参医院名称是包含关系
        if response.json()["result"]:
            for data in response.json()["result"]:
                hospitalNameList.append(data["hname"])
            for name in hospitalNameList:
                assert param["name"] in name
        log.info("通过指定名称<%s>查询医院列表接口测试通过! 查询到医院的数量为%s" % ("望海", str(len(response.json()["result"]))))

    def test_to_bind_hospital(self, runEnv):
        url = self.yamlInfo.get_url("toBindHospital")
        param = self.yamlInfo.get_param("toBindHospital")
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        assert response.json()["status"] == 1
        log.info("查询到的全部待绑定医院列表数量为%s" % str(len(response.json()["result"]["data"])))


if __name__ == '__main__':
    import os

    reportPath = get_abs_path() + r"/result/report/hospital_manage.html"

    os.system("py.test " + os.path.dirname(__file__) + "/test_hospital_manage.py -s -l --html=%s" % reportPath)
