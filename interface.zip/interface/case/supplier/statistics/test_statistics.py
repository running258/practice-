# -*- coding: utf-8 -*-
# author: zly
# time:  2018/12/14
import time
import pytest
import json
from common.viewHighSystem import get_abs_path, obj_show_Chinese
from common.viewHighYamlConf import YamlConf
from common.viewHighRequest import SupplyRequests
from common.viewHighLogger import Logger

log = Logger(loggerName="供采统计").getLog()

class TestHomePage(object):
    userToken = {}
    yamlInfo = YamlConf(get_abs_path() + r"/file/yamlFile/home_page.yaml")

    # case0, 用户登录并获取cookie信息，用于后续接口调用的用户凭证
    def test_user_login(self, runEnv, supplierUserInfo):
        supplierUserInfo = eval(supplierUserInfo)
        userName = supplierUserInfo["userName"]
        password = supplierUserInfo["password"]
        log.info("-----供端首页接口自动化测试开始，用户%s_%s登录系统-----" % (userName, password))
        token = SupplyRequests(runEnv).get_user_token(userName=userName, password=password)
        assert len(token["Authorization"]) > 200  # 若成功获取token串，长度不会小于200
        log.info("用户获取到token凭证：%s" % token)
        self.userToken.update(token)
        # 获取登录用户的菜单权限
        SupplyRequests(runEnv).get_user_authorization(token) 

if __name__ == '__main__':
    import os

    reportPath = get_abs_path() + r"/result/report/home_page.html"

    os.system("py.test " + os.path.dirname(__file__) + "/test_home_page.py -s -l --html=%s" % reportPath)
