# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/21 16:38
import pytest
import json
from common.viewHighSystem import get_abs_path, obj_show_Chinese
from common.viewHighYamlConf import YamlConf
from common.viewHighRequest import SupplyRequests
from common.viewHighLogger import Logger

log = Logger(loggerName="小包代理商证件").getLog()


@pytest.mark.usefixtures("initialize_database")
class TestAgentCertificate(object):
    userToken = {}
    yamlInfo = YamlConf(get_abs_path() + r"/file/yamlFile/agent_certificate.yaml")
    agentName = yamlInfo.get_param(nodeName="addAgentEntity")["name"].encode("utf-8")
    agentInfo = {"compId": None, "id": None}  # 存放代理商compId和代理商id
    agentCertificateInfoList = [] # 存放指定代理商下的证件明细列表，用于编辑和换证等接口调用

    # case0, 用户登录并获取cookie信息，用于后续接口调用的用户凭证
    def test_user_login(self, runEnv, supplierUserInfo):
        supplierUserInfo = eval(supplierUserInfo)
        userName = supplierUserInfo["userName"]
        password = supplierUserInfo["password"]
        log.info("-----代理商证件接口自动化测试开始，用户%s_%s登录系统-----" % (userName, password))
        token = SupplyRequests(runEnv).get_user_token(userName=userName, password=password)
        assert len(token["Authorization"]) > 200  # 若成功获取token串，长度不会小于200
        log.info("用户获取到token凭证：%s" % token)
        self.userToken.update(token)
        # 获取登录用户的菜单权限
        SupplyRequests(runEnv).get_user_authorization(token)

    # case1,测试创建厂商实体，用于后续测试材料证件
    @pytest.mark.parametrize('caseId', ["创建代理商实体"], ids=["测试创建代理商实体，用于后续该代理商下的证件"])
    def test_create_agent(self, caseId, runEnv):
        log.info(caseId)  # 为了加用例标题，目前没想到好办法，可以讨论下是否需求强加id。。。
        url = self.yamlInfo.get_url(nodeName="addAgentEntity")
        param = self.yamlInfo.get_param(nodeName="addAgentEntity")
        response = SupplyRequests(runEnv).post(url=url, data=json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        assert response.json()["result"] > self.yamlInfo.get_expected_result(nodeName="addAgentEntity")["result"]
        log.info("代理商实体%s创建成功！" % self.agentName)
        self.agentInfo["compId"] = response.json()["result"]

    # case2,创建代理商证件-医疗器械经营企业许可证
    def test_create_agent_certificate(self, runEnv):
        url = self.yamlInfo.get_url("addAgentCertificate")
        param = self.yamlInfo.get_param("addAgentCertificate")
        # 重新赋值,取新创建的代理商compId 和代理商名称
        param["compId"] = self.agentInfo["compId"]
        param["compName"] = self.agentName
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() ==self.yamlInfo.get_expected_result("addAgentCertificate")
        log.info("代理商<%s>，创建代理商证件-医疗器械经营企业许可证成功" % self.agentName)

    # case3,测试代理商查询功能,根据名称查询代理商id
    def test_query_agent_entity(self, runEnv):
        url = self.yamlInfo.get_url("queryAgentEntityId")
        param = self.yamlInfo.get_param("queryAgentEntityId")
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        agentId = response.json()["result"]["data"][0]["id"]
        assert int(agentId) > 150000
        self.agentInfo["id"] = agentId
        log.info("查询%s的id为:%s" % (self.agentName, str(agentId)))

    # case4,查询代理商证件
    def test_query_agent_certificate(self, runEnv):
        url = self.yamlInfo.get_url("queryAgentCertificateList")
        param = self.yamlInfo.get_param("queryAgentCertificateList")
        # 重新赋值,取新创建的代理商id
        param["id"] = self.agentInfo["id"]
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        agentDetailList = response.json()["result"]["credentialFileAgentDetail"]
        # 将查询到的代理商证件列表,存入agentCertificateInfo对象
        self.agentCertificateInfoList.extend(agentDetailList)
        log.info("指定代理商id下查询到的detail列表为:")
        log.info(obj_show_Chinese(agentDetailList))

    # case5,编辑代理商证件
    def test_edit_agent_certificate(self, runEnv):
        url = self.yamlInfo.get_url(nodeName="editAgentCertificate")
        param = self.agentCertificateInfoList
        # 取出第一个证件并修改证件名称
        param[0]["name"] += "edit"
        param = {"credentialAgentDetailVo": param}
        log.info("代理商证件编辑后的参数为:->")
        log.info(obj_show_Chinese(param))
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() ==self.yamlInfo.get_expected_result("editAgentCertificate")
        log.info("代理商证件编辑成功！")

    # case6, 测试停用代理商证件功能
    def test_disable_agent_certificate(self, runEnv):
        url = self.yamlInfo.get_url("disableAgentCertificate")
        param = {"id": self.agentCertificateInfoList[0]["id"]}
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() ==self.yamlInfo.get_expected_result("disableAgentCertificate")
        log.info("停用代理商证件成功")

    # case7, 测试启用代理商证件功能
    def test_enable_agent_certificate(self, runEnv):
        url = self.yamlInfo.get_url("enableAgentCertificate")
        param = {"id": self.agentCertificateInfoList[0]["id"]}
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() ==self.yamlInfo.get_expected_result("enableAgentCertificate")
        log.info("启用代理商证件成功")

    # case8, 测试代理商证件换证功能
    def test_replace_agent_certificate(self, runEnv):
        url = self.yamlInfo.get_url("replaceAgentCertificate")
        # 将yaml中的参数取出，并将动态代理商id赋值到参数中
        yamlData = self.yamlInfo.get_param("replaceAgentCertificate")
        yamlData["credentialAgentDetailVo"][0]["fileAgentId"] = self.agentInfo["id"]
        # 取出agentCertificateInfoList中的第一个代理商证件，组合完整入参
        param = self.agentCertificateInfoList[0]
        param.update(yamlData)
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() ==self.yamlInfo.get_expected_result("replaceAgentCertificate")
        log.info("代理商证件换证成功")
        log.info(obj_show_Chinese(param))

    # case9, 测试删除代理商证件功能
    def test_delete_agent_certificate(self, runEnv):
        url = self.yamlInfo.get_url("deleteAgentCertificate")
        for param in self.agentCertificateInfoList:
            param["fileProducerId"] = self.agentInfo["id"]
            response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
            log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
            assert response.json() ==self.yamlInfo.get_expected_result("deleteAgentCertificate")
        log.info("删除代理商证件成功")


if __name__ == '__main__':
    import os

    reportPath = r"\ApiTest_DaLian\result\report\agent_certificate_report.html"

    os.system("py.test " + os.path.dirname(__file__) + "/test_agent_certificate.py -s -l --html=%s" % reportPath)

