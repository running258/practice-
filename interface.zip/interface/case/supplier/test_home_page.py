# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/12/5 15:48
import json
from common.viewHighSystem import get_abs_path, obj_show_Chinese
from common.viewHighYamlConf import YamlConf
from common.viewHighRequest import SupplyRequests
from common.viewHighLogger import Logger

log = Logger(loggerName="供应商端首页").getLog()


class TestHomePage(object):
    userToken = {}
    yamlInfo = YamlConf(get_abs_path() + r"/file/yamlFile/home_page.yaml")

    # case0, 用户登录并获取cookie信息，用于后续接口调用的用户凭证
    def test_user_login(self, runEnv, supplierUserInfo):
        supplierUserInfo = eval(supplierUserInfo)
        userName = supplierUserInfo["userName"]
        password = supplierUserInfo["password"]
        log.info("-----供端首页接口自动化测试开始，用户%s_%s登录系统-----" % (userName, password))
        token = SupplyRequests(runEnv).get_user_token(userName=userName, password=password)
        assert len(token["Authorization"]) > 200  # 若成功获取token串，长度不会小于200
        log.info("用户获取到token凭证：%s" % token)
        self.userToken.update(token)
        # 获取登录用户的菜单权限
        SupplyRequests(runEnv).get_user_authorization(token)

    def test_base_action(self, runEnv):
        url = self.yamlInfo.get_url("baseAction")
        param = self.yamlInfo.get_param("baseAction")
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("baseAction")
        log.info("base_action接口测试通过!")

    # 供端首页查询各状态订单数量
    def test_get_header_oderStatus(self, runEnv):
        url = self.yamlInfo.get_url("getHeaderOderStatus")
        param = self.yamlInfo.get_param("getHeaderOderStatus")
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        assert "待入库" in response.content and "待送货" in response.content and "已入库" in response.content
        log.info("各状态下的订单数量为:%s" % response.content)
        log.info("供端首页查询各个状态下的订单数量接口通过!")

    # 供端首页查询证件数量
    def test_get_header_Cert(self, runEnv):
        url = self.yamlInfo.get_url("getHeaderCert")
        param = self.yamlInfo.get_param("getHeaderCert")
        response = SupplyRequests(runEnv).get(url, param, self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        assert len(response.json()) == len(self.yamlInfo.get_expected_result("getHeaderCert"))
        log.info("各个证件大类数据:%s" % response.content)
        log.info("供端首页查询各个状态下的证件数量接口通过!")

    # 供端首页查询待办事项
    def test_get_header_message(self, runEnv):
        url = self.yamlInfo.get_url("getHeaderMessage")
        param = self.yamlInfo.get_param("getHeaderMessage")
        response = SupplyRequests(runEnv).get(url, param, self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        log.info("供端首页待办事项接口测试通过！当前供应商账号下共有待办事项%s个" % len(response.json()["result"]))

    # 供端首页查询公告消息
    def test_get_notice(self, runEnv):
        url = self.yamlInfo.get_url("getNotice")
        param = self.yamlInfo.get_param("getNotice")
        response = SupplyRequests(runEnv).get(url, param, self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        log.info("供端首页公告消息接口测试通过！当前供应商账号下共有公告消息%s条" % len(response.json()["result"]))

    # 供端首页查询banner
    def test_banner(self, runEnv):
        url = self.yamlInfo.get_url("banner")
        param = self.yamlInfo.get_param("banner")
        response = SupplyRequests(runEnv).get(url, param, self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        log.info("供端首页banner接口测试通过！当前供应商账号下共有banner%s个" % len(response.json()["result"]))

    # 供端首页查询医院名称列表
    def test_hospital_name(self, runEnv):
        url = self.yamlInfo.get_url("hospitalName")
        param = self.yamlInfo.get_param("hospitalName")
        response = SupplyRequests(runEnv).get(url, param, self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        if runEnv == "staging":
            name = self.yamlInfo.get_expected_result("hospitalName")["result"]["staging"]
            assert name in response.json()["result"]
        elif runEnv == "demo":
            name = self.yamlInfo.get_expected_result("hospitalName")["result"]["demo"]
            assert name in response.json()["result"]
        log.info("供端首页查询医院名称接口测试通过！当前供应商账号下共有医院%s个" % len(response.json()["result"]))

    # 供端首页getHeaderWorkNum
    def test_get_header_workNum(self, runEnv):
        url = self.yamlInfo.get_url("getHeaderWorkNum")
        param = self.yamlInfo.get_param("getHeaderWorkNum")
        response = SupplyRequests(runEnv).get(url, param, self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        log.info("供端首页getHeaderWorkNum接口测试通过！")


if __name__ == '__main__':
    import os

    reportPath = get_abs_path() + r"/result/report/home_page.html"

    os.system("py.test " + os.path.dirname(__file__) + "/test_home_page.py -s -l --html=%s" % reportPath)
