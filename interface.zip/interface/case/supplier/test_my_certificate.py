# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/23 13:13
import pytest
import json
from common.viewHighSystem import get_abs_path, obj_show_Chinese
from common.viewHighYamlConf import YamlConf
from common.viewHighRequest import SupplyRequests
from common.viewHighLogger import Logger

log = Logger(loggerName="小包我的证件").getLog()


@pytest.mark.usefixtures("initialize_database")
class TestMyCertificate(object):
    userToken = {}
    myCertificateInfo = {}
    yamlInfo = YamlConf(get_abs_path() + r"/file/yamlFile/my_certificate.yaml")
    myCertificateName = yamlInfo.get_param(nodeName="addMyCertificate")["name"].encode("utf-8")

    # case0, 用户登录并获取cookie信息，用于后续接口调用的用户凭证
    def test_user_login(self, runEnv, supplierUserInfo):
        supplierUserInfo = eval(supplierUserInfo)
        userName = supplierUserInfo["userName"]
        password = supplierUserInfo["password"]
        log.info("----我的证件接口自动化测试开始，用户%s_%s登录系统-----" % (userName, password))
        token = SupplyRequests(runEnv).get_user_token(userName=userName, password=password)
        self.userToken.update(token)
        # 获取登录用户的菜单权限
        SupplyRequests(runEnv).get_user_authorization(token)

    # case1,测试创建代理商（我的）证件基本功能
    def test_create_my_certificate(self, runEnv):
        url = self.yamlInfo.get_url(nodeName="addMyCertificate")
        param = self.yamlInfo.get_param(nodeName="addMyCertificate")
        # 设置代理商（我的）id,代理商（我的）名称参数
        response = SupplyRequests(runEnv).post(url=url, data=json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("addMyCertificate")
        log.info("创建代理商（我的）证件成功！")

    # case2,测试指定名称的代理商（我的）证件的查询功能
    def test_query_my_certificate(self, runEnv):
        url = self.yamlInfo.get_url(nodeName="queryMyCertificate")
        param = self.yamlInfo.get_param(nodeName="queryMyCertificate")
        log.info("传入的参数为：%s" % obj_show_Chinese(param))
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == self.yamlInfo.get_expected_result(nodeName="queryMyCertificate")["status"]
        result = response.json()["result"]["data"][0]
        assert param["identifier"] in result["name"], "查询结果有误"
        # 将查询到的我的证件存入myCertificateInfo
        self.myCertificateInfo.update(result)
        log.info("查询到的代理商（我的）证件信息为:")
        log.info(obj_show_Chinese(self.myCertificateInfo))

    # case3,测试编辑代理商（我的）证件功能
    def test_edit_my_certificate(self, runEnv):
        url = self.yamlInfo.get_url(nodeName="editMyCertificate")
        param = self.myCertificateInfo
        param["name"] += "edit"
        log.info("修改后的证件参数是：%s" % obj_show_Chinese(param))
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("editMyCertificate")
        log.info("编辑我的证件成功！")

    # case4, 测试停用代理商（我的）证件功能
    def test_disable_material_certificate(self, runEnv):
        url = self.yamlInfo.get_url("disableMyCertificate")
        param = {"id": self.myCertificateInfo["id"]}
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("disableMyCertificate")
        log.info("停用代理商（我的）证件成功")

    # case5, 测试启用代理商（我的）证件功能
    def test_enable_my_certificate(self, runEnv):
        url = self.yamlInfo.get_url("enableMyCertificate")
        param = {"id": self.myCertificateInfo["id"]}
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("enableMyCertificate")
        log.info("启用代理商（我的）证件成功")

    # case6, 测试代理商（我的）证件换证功能
    def test_replace_my_certificate(self, runEnv):
        url = self.yamlInfo.get_url("replaceMyCertificate")
        param = self.myCertificateInfo
        newCerParam = self.yamlInfo.get_param("replaceMyCertificate")["credentialFileSupplier"]
        # 拼接myCertificateInfo和yaml中的参数，组成换证入参
        param.update({"credentialFileSupplier": newCerParam})
        log.info("换证接口传入的参数为：%s" % obj_show_Chinese(param))
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("replaceMyCertificate")
        log.info("代理商（我的）证件换证成功！")

    # case7, 测试删除代理商（我的）证件功能
    def test_delete_my_certificate(self, runEnv):
        url = self.yamlInfo.get_url("deleteMyCertificate")
        param = self.myCertificateInfo
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("deleteMyCertificate")
        log.info("删除代理商（我的）证件成功")


if __name__ == '__main__':
    import os

    reportPath = r"\ApiTest_DaLian\result\report\my_certificate_report.html"

    os.system("py.test " + os.path.dirname(__file__) + "/test_my_certificate.py -s -l --html=%s" % reportPath)
    # os.system("py.test " + os.path.dirname(__file__) + " -s -l --html=%s" % reportPath)
