# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/19 13:13
import time
import pytest
import json
from common.viewHighSystem import get_abs_path, obj_show_Chinese
from common.viewHighYamlConf import YamlConf
from common.viewHighRequest import SupplyRequests
from common.viewHighLogger import Logger

log = Logger(loggerName="小包材料证件").getLog()


@pytest.mark.usefixtures("initialize_database")
class TestMaterialCertificate(object):
    userToken = {}
    producerName = "接口自动化测试厂商"
    producerInfo = [None]  # 存放厂商id
    materialCertificateInfo = {}
    yamlInfo = YamlConf(get_abs_path() + r"/file/yamlFile/material_certificate.yaml")

    # case0, 用户登录并获取cookie信息，用于后续接口调用的用户凭证
    def test_user_login(self, runEnv, supplierUserInfo):
        supplierUserInfo = eval(supplierUserInfo)
        userName = supplierUserInfo["userName"]
        password = supplierUserInfo["password"]
        log.info("----材料证件接口自动化测试开始，用户%s_%s登录系统-----" % (userName, password))
        token = SupplyRequests(runEnv).get_user_token(userName=userName, password=password)
        self.userToken.update(token)
        # 获取登录用户的菜单权限
        SupplyRequests(runEnv).get_user_authorization(token)

    # case1,测试创建厂商实体，用于后续测试材料证件
    @pytest.mark.parametrize('caseId', ["test_create_producer001"], ids=["测试创建厂商实体，用于后续该厂商下的材料证件"])
    def test_create_producer(self, caseId, runEnv):
        log.info(caseId)  # 为了加用例标题，目前没想到好办法，可以讨论下是否需求强加id。。。
        url = "/api1/api/credential/bindingAndPush/addProducer"
        param = {"name": self.producerName, "type": 2, "_t": int(time.time()) * 1000}
        response = SupplyRequests(runEnv).post(url=url, data=json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        assert response.json()["result"] > 100000
        log.info("厂商名称%s创建成功！" % self.producerName)
        self.producerInfo[0] = response.json()["result"]

    # case2,测试创建材料证件基本功能
    def test_create_material_certificate(self, runEnv):
        url = self.yamlInfo.get_url(nodeName="addCertificate")
        param = self.yamlInfo.get_param(nodeName="addCertificate")
        # 设置厂商id,厂商名称参数
        param["fileProducerId"] = self.producerInfo[0]
        response = SupplyRequests(runEnv).post(url=url, data=json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("addCertificate")
        log.info("材料证件<%s_%s>创建成功！" % (param["typeName"].encode("utf-8"), param["name"].encode("utf-8")))

    # case3,测试查询刚刚创建的材料证件-产品注册证
    def test_query_material_certificate(self, runEnv):
        url = self.yamlInfo.get_url(nodeName="queryCertificate")
        param = self.yamlInfo.get_param(nodeName="queryCertificate")
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == self.yamlInfo.get_expected_result(nodeName="queryCertificate")["status"]
        result = response.json()["result"]["data"][0]
        assert param["identifier"] in result["name"], "查询结果有误"
        self.materialCertificateInfo.update(result)
        log.info("查询到的材料证件信息为:%s" % obj_show_Chinese(self.materialCertificateInfo))

    # case4,测试编辑材料证件功能
    def test_edit_material_certificate(self, runEnv):
        url = self.yamlInfo.get_url(nodeName="editCertificate")
        param = self.materialCertificateInfo
        param["name"] += "edit"
        log.info("修改后的证件参数是：%s" % obj_show_Chinese(param))
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("editCertificate")
        log.info("编辑材料证件成功！")

    # case5, 测试停用材料证件功能
    def test_disable_material_certificate(self, runEnv):
        url = self.yamlInfo.get_url("disableCertificate")
        param = {"id": self.materialCertificateInfo["id"]}
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() ==self.yamlInfo.get_expected_result("disableCertificate")
        log.info("停用材料证件成功")

    # case6, 测试启用材料证件功能
    def test_enable_material_certificate(self, runEnv):
        url = self.yamlInfo.get_url("enableCertificate")
        param = {"id": self.materialCertificateInfo["id"]}
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() ==self.yamlInfo.get_expected_result("enableCertificate")
        log.info("启用材料证件成功")

    # case7, 测试材料证件换证功能
    def test_replace_material_certificate(self, runEnv):
        url = self.yamlInfo.get_url("replaceCertificate")
        param = self.materialCertificateInfo
        # 为yaml中的动态参数赋值
        newCerParam = self.yamlInfo.get_param("replaceCertificate")["credentialProducerDetailVo"]
        newCerParam[0]["fileProducerId"] = self.producerInfo[0]
        newCerParam[0]["fileProducerName"] = self.producerName

        param.update({"credentialFileMaterial": newCerParam})
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() ==self.yamlInfo.get_expected_result("replaceCertificate")
        log.info("材料证件换证成功！")

    # case8, 测试删除材料证件功能
    def test_delete_material_certificate(self, runEnv):
        url = self.yamlInfo.get_url("deleteCertificate")
        param = self.materialCertificateInfo
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() ==self.yamlInfo.get_expected_result("deleteCertificate")
        log.info("删除材料证件成功")


if __name__ == '__main__':
    import os

    reportPath = get_abs_path() + r"/result/report/ApiTest_Dalian_report.html"

    os.system("py.test " + os.path.dirname(__file__) + r"\test_material_certificate.py -v -s --html=%s" % reportPath)

    # pytest.main(
    #     r"\ApiTest_DaLian\case\supplier\test_material_certificate.py --html=\ApiTest_DaLian\result\report\material_certificate_report.html")
