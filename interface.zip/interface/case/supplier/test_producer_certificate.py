# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/9 13:13
import time
import pytest
import json
from common.viewHighSystem import get_abs_path, obj_show_Chinese
from common.viewHighYamlConf import YamlConf
from common.viewHighRequest import SupplyRequests
from common.viewHighLogger import Logger

log = Logger(loggerName="小包厂商证件").getLog()


@pytest.mark.usefixtures("initialize_database")
class TestProducerCertificate(object):
    userToken = {}
    producerName = "接口自动化测试厂商"
    producerInfo = [None]  # 存放厂商id
    allProducerCertificateInfoList = []
    yamlInfo = YamlConf(get_abs_path() + r"/file/yamlFile/producer_certificate.yaml")

    # case0, 用户登录并获取cookie信息，用于后续接口调用的用户凭证
    def test_user_login(self, runEnv, supplierUserInfo):
        supplierUserInfo = eval(supplierUserInfo)
        userName = supplierUserInfo["userName"]
        password = supplierUserInfo["password"]
        log.info("----厂商证件接口自动化测试开始，用户%s_%s登录系统-----" % (userName, password))
        token = SupplyRequests(runEnv).get_user_token(userName=userName, password=password)
        self.userToken.update(token)
        # 获取登录用户的菜单权限
        SupplyRequests(runEnv).get_user_authorization(token)

    # case1,测试创建厂商实体，用于后续测试厂商证件
    @pytest.mark.parametrize('caseId', ["test_create_producer001"], ids=["测试创建厂商实体，用于后续测试厂商证件"])
    def test_create_producer(self, caseId, runEnv):
        log.info(caseId)  # 为了加用例标题，目前没想到好办法，可以讨论下是否需求强加id。。。
        url = "/api1/api/credential/bindingAndPush/addProducer"
        param = {"name": self.producerName, "type": 1, "_t": int(time.time()) * 1000}
        response = SupplyRequests(runEnv).post(url=url, data=json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == 1
        assert response.json()["result"] > 100000
        log.info("厂商名称%s创建成功！" % self.producerName)
        self.producerInfo[0] = response.json()["result"]

    # case2,测试创建厂商证件基本功能
    def test_create_producer_certificate(self, runEnv):
        url = self.yamlInfo.get_url(nodeName="addCertificate")
        param = self.yamlInfo.get_param(nodeName="addCertificate")
        # 设置厂商id,厂商名称参数
        param["producerId"] = self.producerInfo[0]
        param["producerName"] = self.producerName
        response = SupplyRequests(runEnv).post(url=url, data=json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("addCertificate")
        log.info("创建厂商证件成功！")

    # case3,测试指定名称的厂商证件的查询功能
    def test_query_producer_certificate(self, runEnv):
        url = self.yamlInfo.get_url(nodeName="queryAllProducerCertificate")
        param = self.yamlInfo.get_param(nodeName="queryAllProducerCertificate")
        # 设置厂商名称参数
        param["identifier"] = self.producerName
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json()["status"] == self.yamlInfo.get_expected_result(nodeName="queryAllProducerCertificate")["status"]
        resultList = response.json()["result"]["data"][0]["credentialFileProducerDetail"]
        assert resultList != [], "厂商证件列表为空,查询结果有误!"
        self.allProducerCertificateInfoList.extend(resultList)
        log.info("查询到的厂商证件信息为:%s" % obj_show_Chinese(self.allProducerCertificateInfoList))

    # case4,测试编辑厂商证件功能
    def test_edit_producer_certificate(self, runEnv):
        url = self.yamlInfo.get_url(nodeName="editCertificate")
        param = self.allProducerCertificateInfoList
        # 取出第一个证件并修改证件名称
        param[0]["name"] += "edit"
        param = {"credentialFileProducerDetail": param}
        log.info("编辑厂商证件接口入参为：%s" % obj_show_Chinese(param))
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("editCertificate")
        log.info("编辑厂商证件成功！")

    # case5, 测试停用厂商证件功能
    def test_disable_producer_certificate(self, runEnv):
        url = self.yamlInfo.get_url("disableCertificate")
        param = {"id": self.allProducerCertificateInfoList[0]["id"]}
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("disableCertificate")
        log.info("停用厂商证件成功")

    # case6, 测试启用厂商证件功能
    def test_enable_producer_certificate(self, runEnv):
        url = self.yamlInfo.get_url("enableCertificate")
        param = {"id": self.allProducerCertificateInfoList[0]["id"]}
        response = SupplyRequests(runEnv).get(url, param, headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("enableCertificate")
        log.info("启用厂商证件成功")

    # case7, 测试厂商证件换证功能
    def test_replace_producer_certificate(self, runEnv):
        url = self.yamlInfo.get_url("replaceCertificate")
        param = self.allProducerCertificateInfoList[0]
        param.update(self.yamlInfo.get_param("replaceCertificate"))
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("replaceCertificate")
        log.info("厂商证件换证成功！")

    # case8, 测试删除厂商证件功能
    def test_delete_producer_certificate(self, runEnv):
        url = self.yamlInfo.get_url("deleteCertificate")
        param = self.allProducerCertificateInfoList[0]
        response = SupplyRequests(runEnv).post(url, json.dumps(param), headers=self.userToken)
        log.info("当前请求traceId是:%s" % SupplyRequests().get_traceId(response))
        assert response.json() == self.yamlInfo.get_expected_result("deleteCertificate")
        log.info("删除厂商证件成功")


if __name__ == '__main__':
    import os

    reportPath = get_abs_path() + r"/result/report/material_certificate_report.html"

    os.system("py.test " + os.path.dirname(
        __file__) + "/test_producer_certificate.py -s --supplierUserInfo={'userName':'taojin001','password':'taojin1234','supplierName':'哈哈'} -l --html=%s" % reportPath)
