# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/5 15:31

import json
import requests
from common.viewHighLogger import Logger
from common.viewHighDecorator import function_retry
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# 为了去掉请求的warn提示信息
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
log = Logger(loggerName="接口调用基类").getLog()


# 供端接口基类
class SupplyRequests(object):
    # 运行环境以及运行端
    def __init__(self, runEnv="staging"):
        """
        :param runEnv: ["test", "staging", "demo"] 三个环境
        """
        envList = ["test", "staging", "demo"]
        if runEnv in envList:
            self.baseUrl = "https://vhsupply.{0}.viewchain.net".format(runEnv)
        else:
            log.info("系统环境有误，供应商端目前仅支持test/staging/demo环境")

    def post(self, url, data=None, json=None, headers=None):
        """
        :param url: 传入除去基础域名外的接口url部分
        :param data: 传入python类型的入参数据，如dict/list等
        :param headers: 传入接口请求认证信息
        :return:
        """
        if "http" in url:  # 防止填写了完整的接口地址，导致调用失败
            url = url.split("net")[1]
        response = requests.post(self.baseUrl + url, data, json=json, headers=headers, verify=False)
        assert response.status_code == 200, "接口请求失败，%s" % response.content
        log.info("供端接口<%s>请求,返回状态值<%s>" % (url, str(response.status_code)))
        response.close()
        return response

    # 获取traceId
    def get_traceId(self, response):
        """
        :param response: 将整个response请求传入
        :return: traceId 方便开发调查问题
        """
        return response.headers["TRACE_ID"]

    def get(self, url, data=None, headers=None):
        """
        :param url: 传入除去基础域名外的接口url部分
        :param data: 传入python类型的入参数据，如dict/list等
        :param headers: 传入接口请求认证信息
        :return:
        """
        if "http" in url:  # 防止填写了完整的接口地址，导致调用失败
            url = url.split("net")[1]
        response = requests.get(self.baseUrl + url, data, headers=headers, verify=False)
        assert response.status_code == 200, "接口请求失败，%s" % response.content
        log.info("供端接口<%s>请求,返回状态值<%s>" % (url, str(response.status_code)))
        response.close()
        return response

    # 获取供端登录用户的token
    @function_retry(frequency=2)
    def get_user_token(self, userName, password, tokenOnly=True):
        """
        :param userName: 供应商端登录用户名称
        :param password: 供应商端端登录用户密码
        :param tokenOnly: True表示获取token，False表示获取登录接口的全部返回值
        :return: 用户token或登录账号的全部信息
        """
        supplyUrl = "/api1/auth/login"
        supplyData = {"identifier": userName,
                      "password": password}
        response = self.post(supplyUrl, supplyData).json()
        loginMsg = response["msg"]

        if not loginMsg:
            log.info("用户%s_%s登录成功！" % (userName, password))
        else:
            log.info("用户登录失败->%s" % loginMsg.encode("utf-8"))
        if tokenOnly:
            token = response["result"]["token"]
            return {"Authorization": token,
                    "Content-Type": "application/json;charset=UTF-8"}
        else:
            return response

    # 获取用户的菜单权限，无权限用户无法操作相应的接口
    def get_user_authorization(self, userToken):
        resUrl = "/api1/api/user/base/getUserRes?_t=1542943566000"
        response = self.get(url=resUrl, headers=userToken).json()
        assert len(response["result"]) > 0, "登录用户没有权限"
        log.info("已获取登录用户的菜单权限！")

    # 上传图片专用方法
    def post_image_file(self, url, filePath, data=None, cookie=None):
        """
        :param url: 接口地址，基础域名部分可以省略
        :param filePath: 文件的具体路径，包括文件名称和后缀名
        :param data: 一般不用填
        :param cookie: 供端的token信息
        :return: 上传后的url地址
        """
        if "http" in url:  # 防止填写了完整的接口地址，导致调用失败
            url = url.split("net")[1]
        cookie.pop("Content-Type")  # 上传图片的接口不能使用通用的“application/json;charset=UTF-8”header
        response = requests.post(self.baseUrl + url, data, files={'file': open(filePath, 'rb')}, headers=cookie,
                                 verify=False)
        assert response.status_code == 200, "接口请求失败，%s" % response.content
        log.info("供端接口<%s>请求,返回状态值<%s>" % (url, str(response.status_code)))
        response.close()
        imageUrl = response.json()["result"][0]["url"]
        assert any([imageUrl.endswith(e) for e in ["jpg", "png", "gif"]])
        return imageUrl


# 云化院端接口基类
class HospitalRequests(object):
    # 运行环境以及运行端
    def __init__(self, env="staging"):
        """
        :param env: ["test", "staging", "demo"] 三个环境
        """
        envList = ["test", "staging", "demo"]
        if env in envList:
            self.baseUrl = "https://hosp-cloud.{0}.viewchain.net".format(env)
        else:
            log.info("系统环境有误，云化院端目前仅支持test/staging/demo环境")

    def post(self, url, data=None, json=None, cookie=None):
        """
        :param url: 传入除去基础域名外的接口url部分
        :param data: 传入python类型的入参数据，如dict/list等
        :param cookie: 传入接口请求认证信息
        :return:
        """
        if "http" in url:  # 防止填写了完整的接口地址，导致调用失败
            url = url.split("net")[1]
        response = requests.post(self.baseUrl + url, data, json=json, headers=cookie, verify=False)
        assert response.status_code == 200, "接口请求失败，%s" % response.content
        log.info("云化院端接口<%s>请求,返回状态值<%s>" % (url, str(response.status_code)))
        response.close()
        return response

    def get(self, url, data=None, headers=None):
        """
        :param url: 传入除去基础域名外的接口url部分
        :param data: 传入python类型的入参数据，如dict/list等
        :param headers: 传入接口请求认证信息
        :return:
        """
        if "http" in url:  # 防止填写了完整的接口地址，导致调用失败
            url = url.split("net")[1]
        response = requests.get(self.baseUrl + url, data, headers=headers, verify=False)
        assert response.status_code == 200, "接口请求失败，%s" % response.content
        log.info("云化院端接口<%s>请求,返回状态值<%s>" % (url, str(response.status_code)))
        response.close()
        return response

    # 获取云化院端登录用户的token
    @function_retry(frequency=2)
    def get_user_token(self, userName, password, tokenOnly=True):
        """
        :param userName: 云化院端登录用户名称
        :param password: 云化院端登录用户密码
        :param tokenOnly: True表示获取token，False表示获取登录接口的全部返回值
        :return: 用户token或登录账号的全部信息
        """
        hospitalUrl = "/sys/login"
        hospitalData = {"username": userName,
                        "password": password,
                        "captcha": "",
                        "checked": False}

        response = self.post(hospitalUrl, hospitalData)
        if tokenOnly:
            token = response.json()["Authorization"]
            return {"Authorization": token}
        else:
            return response

    # 获取traceId
    def get_traceId(self, response):
        """
        :param response: 将整个response请求传入
        :return: traceId 方便开发调查问题
        """
        return response.headers["TRACE_ID"]

    # 院端上传excel专用方法
    def post_file(self, url, filePath, data=None, cookie=None):
        """
        :param url: 接口地址，基础域名部分可以省略
        :param filePath: 文件的具体路径，包括文件名称和后缀名
        :param data: 一般不用填
        :param cookie: 院端的token信息
        :return:
        """
        if "http" in url:  # 防止填写了完整的接口地址，导致调用失败
            url = url.split("net")[1]
        response = requests.post(self.baseUrl + url, data, files={'file': open(filePath, 'rb')}, headers=cookie,
                                 verify=False)
        assert response.status_code == 200, "接口请求失败，%s" % response.content
        log.info("云化院端接口<%s>请求,返回状态值<%s>" % (url, str(response.status_code)))
        response.close()
        return response.json()


if __name__ == '__main__':
    from common.viewHighSystem import obj_show_Chinese

    url = "http://23423/net/api1/auth/login"
    supplyData = {"identifier": "taojin001",
                  "password": "taojin1234"}
    # req = SupplyRequests().post(url, supplyData)
    # print req
    #
    # hospitalToken = HospitalRequests().get_user_token("whtest001", "test123456")
    # print hospitalToken
    qUrl = "/api1/api/user/base/getUserRes?_t=1542943566000"
    mUrl = "/api1/api/credential/bindingAndPush/listHospitalMaterial"
    data = {"hid": 3,
            "status": 0,
            "name": "",
            "pageSize": 20,
            "pageNum": 1,
            "credMode": 2,
            "_t": 1542937527000}

    supplyToken = SupplyRequests().get_user_token("taojin002", "taojin1234")
    # SupplyRequests().get(qUrl, cookie=supplyToken)
    # uploadUrl = "https://vhsupply.staging.viewchain.net/api1/api/user/base/upload"
    #
    # filePath = r"C:\Users\taojin\Desktop\image\1.1.1.jpg"
    # files = {'file': ('333.jpg', open(filePath, 'rb'), 'image/jpeg', {})}
    # files2 = {'file': open(filePath, 'rb')}
    # supplyToken.pop("Content-Type")
    # print supplyToken
    # res = requests.post(uploadUrl, files=files2, headers=supplyToken)
    # print res.content
    # print SupplyRequests().post_image_file(uploadUrl, filePath, cookie=supplyToken)

    aData = {"identifier": "", "index": "1"}
    aUrl = "https://vhsupply.staging.viewchain.net/api1/api/credential/materialcred/listMaterialCredential"
    aResq = SupplyRequests().post(aUrl, json.dumps(aData), headers=supplyToken)
    print(aResq.content)
    # print  obj_show_Chinese(aResq)
    print SupplyRequests().get_traceId(aResq)
    for k, v in aResq.json().items():
        print k, obj_show_Chinese(v)
