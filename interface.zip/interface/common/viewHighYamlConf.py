# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/14 16:37

import yaml


class YamlConf(object):

    def __init__(self, filePath):
        self.yamlPath = filePath

    # 根据指定的node节点名称,获取相应的节点info
    def get_info(self, nodeName):
        try:
            with open(self.yamlPath) as file:
                yamlDict = yaml.load(file)
                return yamlDict[nodeName]
        except IOError:
            print("未找到Yaml文件,请检查路径地址是否正确!")
        except KeyError:
            print("节点名称配置错误!")

    def get_url(self, nodeName):
        try:
            data = self.get_info(nodeName)
            return data["url"]
        except TypeError:
            print("未找到接地址,请检查节点名称是否有误")

    def get_param(self, nodeName):
        try:
            data = self.get_info(nodeName)
            return data["param"]
        except TypeError:
            print("未找到接口参数,请检查节点名称是否有误")

    def get_expected_result(self, nodeName):
        try:
            data = self.get_info(nodeName)
            return data["expectedResult"]
        except TypeError:
            print("未找到接口预期返回结果,请检查节点名称是否有")

    # 获取该文件下,所有信息
    def get_all(self):
        try:
            with open(self.yamlPath) as file:
                yamlDict = yaml.load(file)
                return yamlDict
        except IOError:
            print("未找到Yaml文件,请检查路径地址是否正确!")


if __name__ == '__main__':
    import json

    file1 = r"\ApiTest_Dalian\file\yamlFile\home_page.yaml"
    param = YamlConf(file1).get_expected_result(nodeName="hospitalName")
    sqlList = []
    for k,v in param.items():
        print k, v
