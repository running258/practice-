# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/26 15:44
import os
import json


# 该方法返回当前文件的绝对路径
def get_abs_path():
    base_dir = str(os.path.dirname(__file__))
    base_dir = base_dir.replace('\\', '/')
    file_path = str(base_dir.split('/common')[0])
    return file_path


# 该方法将不同类型数据结构中含有的中文字符正确显示出来
def obj_show_Chinese(obj):
    if isinstance(obj, dict) or isinstance(obj, list):
        return json.dumps(obj).decode("unicode-escape").encode("utf-8")
    elif isinstance(obj, str):
        return obj.decode("utf-8")
    else:
        return obj


if __name__ == '__main__':
    print get_abs_path()
    a = {"status": 0, "pagination": {"pageNo": 1, "pageSize": 20}, "_t": 1542702086000, "identifier": "接口自动化测试税务登记证"}
    b = [{"status": 0, "pagination": {"pageNo": 1, "pageSize": 20}, "_t": 1542702086000, "identifier": "接口自动化测试税务登记证"}]
    c = ["你好"]
    d = "你好"

    print a
    print b
    print c
    print d
    print obj_show_Chinese(a)
    print(obj_show_Chinese(b))
    print(obj_show_Chinese(c))
    print(obj_show_Chinese(d))
    print get_abs_path()
