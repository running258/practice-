# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/8 14:42

import redis
import json


class Redis(object):
    pool = {"host": "192.168.96.23", "port": 6379, "db": 0}
    connect = redis.StrictRedis(**pool)

    # 字符串形式存入redis
    def setStr(self, name, value):
        self.connect.set(name=name, value=value)

    # key/value形式存入redis
    def setHash(self, name, key, value):
        value = json.dumps(value, ensure_ascii=False)
        self.connect.hset(name=name, key=key, value=value)

    # 通过name获取所有的key
    def get_all_hashKey(self, name):
        value = self.connect.hgetall(name=name)
        keyList = []
        for key in value.keys():
            keyList.append(key.decode("utf-8"))
        return keyList

    # 通过name和key获取相应的value
    def getHash(self, name, key):
        value = self.connect.hget(name=name, key=key)
        value = value.decode("utf-8")
        return json.loads(value)
