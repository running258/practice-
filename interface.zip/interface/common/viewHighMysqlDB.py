# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/8 14:45
import pymysql


# 数据库时间格式转换
def time_format(timeStr):
    timeList = timeStr.split("/") if "/" in timeStr else timeStr.split("-")
    newTimeList = []
    for i in timeList:
        if len(i) == 1:
            newTimeList.append("0" + i)
        else:
            newTimeList.append(i)
    timeStamp = "".join(newTimeList)
    return timeStamp


# 从指定环境指定库中删除数据
def clear_database(env="staging", dbName="viewchaindb_staging", sql_delete=""):
    global db
    envList = ["test", "staging", "demo"]
    if env in envList:
        if env == "staging":
            db = pymysql.connect(host="192.168.96.11", user="viewchainstaging", password="cr+4R!mEsWE5",
                                 db=dbName, port=23306)
        elif env == "test":
            db = pymysql.connect(host="192.168.96.11", user="viewchaindev", password="6emE2AChaS=e",
                                 db=dbName, port=23306)
        elif env == "demo":
            db = pymysql.connect(host="192.168.96.11", user="viewchaindemo", password="bEvuch88EDRE=e",
                                 db=dbName, port=23306)
    else:
        print "目前仅支持staging/test/demo三种环境,请重新设置!"

    # 使用cursor()方法获取操作游标
    cur = db.cursor()

    try:
        # 执行并提交sql语句
        cur.execute(sql_delete)
        db.commit()
    except Exception:
        # 错误回滚
        db.rollback()
    finally:
        db.close()
