# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/16 13:49
import time
import functools
from common.viewHighLogger import Logger

log = Logger(loggerName="viewHighDecorator").getLog()


# 重试装饰器，用于重要模块发生异常时，多次调用，提高自动化脚本容错性，可以指定重试次数和频率
def function_retry(retryCount=3, frequency=1):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kw):
            count = 0
            while count < retryCount:
                try:
                    return func(*args, **kw)
                except Exception, e:
                    log.info("调用<%s>方法时发生?%s?异常，系统即将进行第%s次重试，共%s次！" % (func.__name__, e, count + 1, retryCount))
                    count += 1
                    time.sleep(frequency)

        return wrapper

    return decorator