# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/5 15:26
import time
import logging
import viewHighSystem


class Logger:
    # 文件日志格式
    LOGGING_FORMAT = '%(asctime)s %(name)s[line:%(lineno)d] %(levelname)s %(message)s'

    def __init__(self,
                 level=logging.DEBUG,  # 日志级别
                 fmt=LOGGING_FORMAT,  # 日志格式
                 dateFormat='%a, %d %b %Y %H:%M:%S',  # 日期格式
                 filename=viewHighSystem.get_abs_path() + r"/result/log/{0}.log".format(time.ctime()[:3]),  # 日志文件名
                 filemode='w',  # 文件打开模式
                 loggerName=""
                 ):
        self.level = level
        self.format = fmt
        self.dateFormat = dateFormat
        self.filename = filename
        self.filemode = filemode

        # 初始化日志同时输出到console和日志文件
        logging.basicConfig(level=self.level,
                            format=self.format,
                            datefmt=self.dateFormat,
                            filename=self.filename,
                            filemode=self.filemode)

        # 定义一个StreamHandler，将INFO级别或更高的日志信息打印到控制台
        # 并将其添加到当前的日志处理对象
        console = logging.StreamHandler()
        console.setLevel(logging.INFO)

        # 定义一个FileHandler，将DEBUG级别日志记录到文件
        # 并将其添加到当前的日志处理对象
        fileLog = logging.FileHandler(filename=self.filename, encoding="utf-8")
        fileLog.setLevel(logging.DEBUG)

        # 设置日志格式
        formatter = logging.Formatter('%(name)s[line:%(lineno)d]: %(levelname)-10s %(message)s')

        # 控制台输出日志格式
        console.setFormatter(formatter)
        fileLog.setFormatter(self.LOGGING_FORMAT)

        self.logger = logging.getLogger(loggerName)
        self.logger.addHandler(console)
        self.logger.addHandler(fileLog)

    def getLog(self):
        return self.logger
