# -*- coding: utf-8 -*-
# author: taojin
# time:  2018/11/13 11:01
import json
from common.request import HospitalRequests

token = HospitalRequests().get_user_token("whtest003", "test123456")

url = "/dictmaterial/material/import"
filePath = 'C:\\Users\\taojin\\Desktop\\import_material.xlsx'

# req = HospitalRequests().post(url, data=data, files=files, cookie=token)
# print json.dumps(req).decode("unicode-escape")
# raq = HospitalRequests().get("https://hosp-cloud.staging.viewchain.net/dict/vendorbind/list?venName=&page=1&limit=20",cookie=token)
# print  json.dumps(raq).decode("unicode-escape")
response = HospitalRequests().post(url=url, files={'file': open(filePath, 'rb')}, cookie=token)
print json.dumps(response).decode("unicode-escape")
print 111222
